define({
  "_widgetLabel": "Galvene",
  "signin": "Pierakstīties",
  "signout": "Izrakstīties",
  "about": "Par",
  "signInTo": "Pierakstīties",
  "cantSignOutTip": "Šī funkcija nav pieejama priekšskatījuma režīmā.",
  "more": "vairāk"
});